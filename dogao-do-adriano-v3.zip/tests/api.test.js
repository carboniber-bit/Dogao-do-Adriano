// Testes da API (sem rede): Supabase e Mercado Pago simulados. Rodar: node tests/api.test.js
const { test, beforeEach } = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("crypto");
const h = require("./harness");
const { est, chamar, api, aprovar, definirStatus } = h;

const checkout = api("checkout.js"), pedido = api("pedido.js"), webhook = api("webhook.js"), conta = api("conta.js"), admin = api("admin.js"), status = api("status.js"), menu = api("menu.js");

const base = (extra = {}) => ({ nome: "Maria da Silva", telefone: "(11) 99999-1234", tipo: "Delivery", endereco: "Rua das Flores, 123", obs: "", email: "maria@exemplo.com",
  itens: [{ id: "agua", q: 2 }], ...extra });
const pedirPix = (extra, headers) => chamar(checkout, { method: "POST", body: { ...base(), modo: "pix", ...extra }, headers });
const consultar = (ref) => chamar(pedido, { query: { ref } });
const doDb = (ref) => est.tabelas.pedidos.find((p) => p.ref === ref);

async function comRelogio(iso, fn) {
  const Real = Date, fixo = new Real(iso).getTime();
  global.Date = class extends Real { constructor(...a) { if (a.length) super(...a); else super(fixo); } static now() { return fixo; } };
  process.env.IGNORAR_HORARIO = "";
  try { return await fn(); } finally { global.Date = Real; process.env.IGNORAR_HORARIO = "1"; }
}
async function capturandoErros(fn) {
  const orig = console.error, linhas = [];
  console.error = (...a) => linhas.push(a.map(String).join(" "));
  try { return [await fn(), linhas.join("\n")]; } finally { console.error = orig; }
}

beforeEach(() => { h.reiniciar(); process.env.IGNORAR_HORARIO = "1"; delete process.env.MP_WEBHOOK_SECRET; });

/* ===== 1. Pix: criação ===== */
test("Pix: 200 com copia e qr; pedido aguardando_pagamento com mp_payment_id e mp_metodo=Pix", async () => {
  const r = await pedirPix();
  assert.equal(r.status, 200);
  assert.ok(r.corpo.pix.copia.startsWith("000201"));
  assert.ok(r.corpo.pix.qr.length > 20);
  assert.ok(r.corpo.pix.expira && r.corpo.pix.url && r.corpo.pix.id);
  const p = doDb(r.corpo.ref);
  assert.equal(p.status, "aguardando_pagamento");
  assert.equal(p.forma, "online");
  assert.equal(p.mp_payment_id, r.corpo.pix.id);
  assert.equal(p.mp_metodo, "Pix");
  assert.equal(p.user_id, null);
});

test("Pix: corpo enviado ao Mercado Pago segue a especificação", async () => {
  const r = await pedirPix();
  const { headers, body } = est.mp.chamadasCriar[0];
  assert.equal(headers["X-Idempotency-Key"], r.corpo.ref);
  assert.equal(headers.Authorization, `Bearer ${process.env.MP_ACCESS_TOKEN}`);
  assert.equal(body.payment_method_id, "pix");
  assert.equal(body.external_reference, r.corpo.ref);
  assert.equal(body.notification_url, "https://dogao.test/api/webhook");
  assert.equal(body.description, `Dogão do Adriano ${r.corpo.ref}`);
  assert.deepEqual(body.payer, { email: "maria@exemplo.com", first_name: "Maria", last_name: "da Silva" });
  assert.match(body.date_of_expiration, /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}-03:00$/);
  const dif = Date.parse(body.date_of_expiration) - Date.now();
  assert.ok(dif > 29 * 60000 && dif < 31 * 60000, "expira em ~30 min, deu " + dif);
  assert.equal("statement_descriptor" in body, false);
  assert.equal(body.metadata.ref, r.corpo.ref);
  assert.match(body.metadata.pedido, /2x Água/);
  assert.ok(body.additional_info.items.length >= 1);
});

test("Pix: nome de uma palavra só usa o primeiro nome como sobrenome", async () => {
  await pedirPix({ nome: "Cher" });
  assert.deepEqual([est.mp.chamadasCriar[0].body.payer.first_name, est.mp.chamadasCriar[0].body.payer.last_name], ["Cher", "Cher"]);
});

test("Pix: total vem do servidor mesmo com preço adulterado no navegador", async () => {
  const r = await pedirPix({ itens: [{ id: "agua", q: 2, preco: 0.01, unit_price: 0.01 }], total: 0.02, subtotal: 0.02, taxa: 0 });
  assert.equal(r.status, 200);
  assert.equal(r.corpo.total, 16); // 2 x 5 + taxa 6
  assert.equal(est.mp.chamadasCriar[0].body.transaction_amount, 16);
  const p = doDb(r.corpo.ref);
  assert.deepEqual([p.subtotal, p.taxa, p.total], [10, 6, 16]);
  assert.equal(p.itens[0].preco, 5);
});

test("Pix: retirada não cobra taxa; item com pão escolhido", async () => {
  const r = await pedirPix({ tipo: "Retirada", itens: [{ id: "tradicional", pao: "Sal", q: 1 }] });
  assert.equal(r.corpo.total, 18);
  assert.equal(doDb(r.corpo.ref).itens[0].pao, "Sal");
});

test("Pix: usuário logado grava user_id", async () => {
  const r = await pedirPix({}, { authorization: "Bearer tok-cliente" });
  assert.equal(doDb(r.corpo.ref).user_id, "u-cliente");
});

test("Pix: o e-mail não é gravado no banco nem aparece nos logs", async () => {
  const [r, logs] = await capturandoErros(async () => { const x = await pedirPix(); est.mp.falhar = { status: 400, corpo: { message: "erro com maria@exemplo.com" } }; await pedirPix(); return x; });
  assert.equal(r.status, 200);
  assert.equal(JSON.stringify(est.tabelas).includes("maria@exemplo.com"), false);
  assert.equal(logs.includes("maria@exemplo.com"), false);
  assert.equal(logs.includes(process.env.MP_ACCESS_TOKEN), false);
});

/* ===== 2. Validações ===== */
test("Pix: e-mail ausente ou inválido -> 400", async () => {
  for (const email of [undefined, "", "   ", "sem-arroba", "a@b", "a b@c.com", "x".repeat(121) + "@a.com"]) {
    const r = await pedirPix({ email });
    assert.equal(r.status, 400, `email=${email}`);
    assert.equal(r.corpo.erro, "Informe um e-mail válido para o Pix.");
  }
  assert.equal(est.tabelas.pedidos.length, 0);
  assert.equal(est.mp.chamadasCriar.length, 0);
});

test("Pix: fora do horário -> 409 e nada é gravado", async () => {
  // terça-feira 22:00 em São Paulo: delivery não funciona às terças
  const r = await comRelogio("2026-10-28T01:00:00Z", () => pedirPix({ tipo: "Delivery" }));
  assert.equal(r.status, 409);
  assert.match(r.corpo.erro, /^Fechado agora\./);
  // quarta 12:00: retirada ainda fechada
  const r2 = await comRelogio("2026-10-28T15:00:00Z", () => pedirPix({ tipo: "Retirada" }));
  assert.equal(r2.status, 409);
  assert.equal(est.tabelas.pedidos.length, 0);
  assert.equal(est.mp.chamadasCriar.length, 0);
});

test("Pix: item inexistente, desativado, de encomenda ou quantidade inválida -> 400", async () => {
  for (const itens of [[{ id: "nao-existe", q: 1 }], [{ id: "sumido", q: 1 }], [{ id: "festa", q: 1 }], [{ id: "agua", q: 0 }], [{ id: "agua", q: 21 }], [{ id: "agua", q: 1.5 }], []]) {
    const r = await pedirPix({ itens });
    assert.equal(r.status, 400, JSON.stringify(itens));
  }
  assert.equal(est.tabelas.pedidos.length, 0);
});

test("Pix: demais validações (nome, telefone, tipo, endereço) e método", async () => {
  assert.equal((await pedirPix({ nome: "A" })).status, 400);
  assert.equal((await pedirPix({ telefone: "123" })).status, 400);
  assert.equal((await pedirPix({ tipo: "Voando" })).status, 400);
  assert.equal((await pedirPix({ endereco: "x" })).status, 400);
  assert.equal((await chamar(checkout, { method: "GET" })).status, 405);
});

test("Pix: sem MP_ACCESS_TOKEN -> 503", async () => {
  const t = process.env.MP_ACCESS_TOKEN; delete process.env.MP_ACCESS_TOKEN;
  try { assert.equal((await pedirPix()).status, 503); } finally { process.env.MP_ACCESS_TOKEN = t; }
});

test("Pix: se não conseguir gravar o pedido -> 500 e não cobra", async () => {
  est.dbFalhaPedidos = true;
  const [r] = await capturandoErros(() => pedirPix());
  assert.equal(r.status, 500);
  assert.equal(est.mp.chamadasCriar.length, 0);
});

/* ===== 3. Falha do Mercado Pago ===== */
test("Pix: erro de chave Pix no MP -> 502 amigável e pedido cancelado", async () => {
  est.mp.falhar = { status: 400, corpo: { message: "Collector user without key enabled for QR render", error: "bad_request", status: 400 } };
  const [r, logs] = await capturandoErros(() => pedirPix());
  assert.equal(r.status, 502);
  assert.equal(r.corpo.erro, "Pix indisponível no momento. Pague com cartão ou combine pelo WhatsApp.");
  assert.equal(est.tabelas.pedidos.length, 1);
  assert.equal(est.tabelas.pedidos[0].status, "cancelado");
  assert.match(logs, /Collector user without key enabled for QR render/); // log detalhado para o dono
  assert.match(logs, /400/);
});

test("Pix: resposta do MP sem transaction_data também cancela", async () => {
  const antes = global.fetch;
  global.fetch = async (u, i) => (String(u).endsWith("/v1/payments") && i.method === "POST" ? h.resp(201, { id: 1, status: "pending" }) : antes(u, i));
  try {
    const [r] = await capturandoErros(() => pedirPix());
    assert.equal(r.status, 502);
    assert.equal(est.tabelas.pedidos[0].status, "cancelado");
  } finally { global.fetch = antes; }
});

test("Pix: falha de rede com o MP -> 502 e pedido cancelado", async () => {
  const antes = global.fetch;
  global.fetch = async (u, i) => { if (String(u).includes("mercadopago.com")) throw new Error("ECONNRESET"); return antes(u, i); };
  try {
    const [r] = await capturandoErros(() => pedirPix());
    assert.equal(r.status, 502);
    assert.equal(est.tabelas.pedidos[0].status, "cancelado");
  } finally { global.fetch = antes; }
});

/* ===== 4. /api/pedido, webhook, aviso único ===== */
test("/api/pedido: aguardando -> aprovação no MP -> pago, aviso Telegram uma única vez (webhook + polling)", async () => {
  const { corpo: { ref, pix } } = await pedirPix();
  assert.deepEqual((await consultar(ref)).corpo, { status: "aguardando_pagamento" });
  assert.deepEqual((await consultar(ref)).corpo, { status: "aguardando_pagamento" });
  assert.equal(est.telegram.length, 0);

  aprovar(pix.id);
  const hook = () => chamar(webhook, { method: "POST", body: { type: "payment", data: { id: pix.id } } });
  const rs = await Promise.all([consultar(ref), hook(), consultar(ref), hook(), consultar(ref)]);
  rs.filter((r) => r.corpo && r.corpo.status).forEach((r) => assert.equal(r.corpo.status, "pago"));
  rs.filter((r) => r.corpo === "ok").forEach((r) => assert.equal(r.status, 200));
  await hook(); await consultar(ref); await hook();

  assert.deepEqual((await consultar(ref)).corpo, { status: "pago" });
  assert.equal(est.telegram.length, 1, "o aviso deve sair uma única vez");
  assert.match(est.telegram[0], /^✅ PAGAMENTO APROVADO \(Pix\)\n\nPedido /);
  assert.match(est.telegram[0], /2x Água/);
  assert.match(est.telegram[0], /Nome: Maria da Silva/);
  const p = doDb(ref);
  assert.equal(p.status, "pago"); assert.equal(p.mp_metodo, "Pix"); assert.equal(p.mp_payment_id, pix.id); assert.ok(p.pago_em);
});

test("webhook sozinho: aprovado marca pago e avisa uma vez; polling depois não reenvia", async () => {
  const { corpo: { ref, pix } } = await pedirPix();
  aprovar(pix.id);
  for (let i = 0; i < 3; i++) assert.equal((await chamar(webhook, { method: "POST", body: { type: "payment", data: { id: pix.id } } })).status, 200);
  await consultar(ref);
  assert.equal(est.telegram.length, 1);
});

test("webhook: id em query string (formato antigo) e tópico diferente de payment é ignorado", async () => {
  const { corpo: { pix } } = await pedirPix();
  aprovar(pix.id);
  const antes = est.mp.chamadasConsulta;
  await chamar(webhook, { method: "POST", query: { topic: "merchant_order", id: pix.id } });
  assert.equal(est.mp.chamadasConsulta, antes);
  assert.equal((await chamar(webhook, { method: "POST", query: { topic: "payment", id: pix.id } })).status, 200);
  assert.equal(est.telegram.length, 1);
});

test("webhook: consulta ao MP falhou -> 500 (o MP reenvia)", async () => {
  const { corpo: { pix } } = await pedirPix();
  est.mp.consultaFalha = true;
  const r = await chamar(webhook, { method: "POST", body: { type: "payment", data: { id: pix.id } } });
  assert.equal(r.status, 500);
});

test("webhook: assinatura (MP_WEBHOOK_SECRET) válida passa, inválida/ausente -> 401", async () => {
  const { corpo: { pix } } = await pedirPix();
  process.env.MP_WEBHOOK_SECRET = "segredo";
  const ts = "1700000000", rid = "req-1";
  const v1 = crypto.createHmac("sha256", "segredo").update(`id:${pix.id};request-id:${rid};ts:${ts};`).digest("hex");
  const corpo = { type: "payment", data: { id: pix.id } };
  assert.equal((await chamar(webhook, { method: "POST", body: corpo, headers: { "x-signature": `ts=${ts},v1=${v1}`, "x-request-id": rid } })).status, 200);
  assert.equal((await chamar(webhook, { method: "POST", body: corpo, headers: { "x-signature": `ts=${ts},v1=${"0".repeat(64)}`, "x-request-id": rid } })).status, 401);
  assert.equal((await chamar(webhook, { method: "POST", body: corpo })).status, 401);
});

test("rejeitado -> recusado; depois aprovado -> pago (aviso uma vez); cancelado/estornado -> cancelado", async () => {
  const a = (await pedirPix()).corpo, b = (await pedirPix()).corpo;
  definirStatus(a.pix.id, "rejected");
  assert.deepEqual((await consultar(a.ref)).corpo, { status: "recusado" }); // /api/pedido aplica o rejected e relê
  assert.equal(doDb(a.ref).status, "recusado");
  aprovar(a.pix.id);
  await chamar(webhook, { method: "POST", body: { type: "payment", data: { id: a.pix.id } } });
  assert.equal(doDb(a.ref).status, "pago"); assert.equal(est.telegram.length, 1);

  definirStatus(b.pix.id, "cancelled");
  await chamar(webhook, { method: "POST", body: { type: "payment", data: { id: b.pix.id } } });
  assert.equal(doDb(b.ref).status, "cancelado");
  definirStatus(a.pix.id, "refunded");
  await chamar(webhook, { method: "POST", body: { type: "payment", data: { id: a.pix.id } } });
  assert.equal(doDb(a.ref).status, "cancelado");
});

test("mp_metodo: cartão de crédito/débito e outros", async () => {
  const mk = async (extra) => { const r = (await pedirPix()).corpo; est.tabelas.pedidos.find((p) => p.ref === r.ref).mp_metodo = null; aprovar(r.pix.id, extra); await chamar(webhook, { method: "POST", body: { type: "payment", data: { id: r.pix.id } } }); return doDb(r.ref).mp_metodo; };
  assert.equal(await mk({ payment_method_id: "visa", payment_type_id: "credit_card" }), "Cartão de crédito");
  assert.equal(await mk({ payment_method_id: "debvisa", payment_type_id: "debit_card" }), "Cartão de débito");
  assert.equal(await mk({ payment_method_id: "account_money", payment_type_id: "account_money" }), "account_money");
  assert.equal(await mk({}), "Pix");
});

/* ===== 5. /api/pedido: validação e privacidade ===== */
test("/api/pedido: ref inválido 400, inexistente 404, método 405, no-store", async () => {
  for (const ref of ["", "abc", "minúsculo123", "DA-123456", "A".repeat(25), "DA123456'; drop", undefined]) assert.equal((await consultar(ref)).status, 400, String(ref));
  const r = await consultar("DAINEXISTENTE");
  assert.equal(r.status, 404);
  assert.equal(r.headers["cache-control"], "no-store");
  assert.equal((await chamar(pedido, { method: "POST", query: { ref: "DAINEXISTENTE" } })).status, 405);
});

test("/api/pedido: resposta nunca contém dados pessoais, em nenhum status", async () => {
  const { corpo: { ref, pix } } = await pedirPix({ nome: "Fulano Sigiloso", telefone: "11988887777", endereco: "Rua Secreta 999", obs: "segredo" });
  for (const fase of ["pendente", "pago"]) {
    if (fase === "pago") aprovar(pix.id);
    const r = await consultar(ref);
    assert.deepEqual(Object.keys(r.corpo), ["status"]);
    const txt = JSON.stringify(r);
    for (const sens of ["Fulano", "11988887777", "Secreta", "segredo", "maria@", "9000"]) assert.equal(txt.includes(sens), false, sens);
  }
});

test("/api/pedido: sem banco configurado -> 400", async () => {
  const k = process.env.SUPABASE_SERVICE_ROLE_KEY;
  // _lib lê as variáveis ao carregar; recarrega o módulo sem a chave para simular "sem banco"
  const caminhos = ["_lib.js", "_pagamento.js", "pedido.js"].map((n) => require.resolve("../api/" + n));
  const guardados = caminhos.map((c) => [c, require.cache[c]]);
  caminhos.forEach((c) => delete require.cache[c]);
  process.env.SUPABASE_SERVICE_ROLE_KEY = "";
  try { assert.equal((await chamar(require("../api/pedido.js"), { query: { ref: "DAABCDEF12" } })).status, 400); }
  finally { process.env.SUPABASE_SERVICE_ROLE_KEY = k; caminhos.forEach((c) => delete require.cache[c]); guardados.forEach(([c, m]) => { require.cache[c] = m; }); }
});

test("/api/pedido: falha ao consultar o MP não derruba; devolve o status atual", async () => {
  const { corpo: { ref } } = await pedirPix();
  est.mp.consultaFalha = true;
  assert.deepEqual((await consultar(ref)).corpo, { status: "aguardando_pagamento" });
});

/* ===== 7. Regressão ===== */
test("regressão: cartão (Checkout Pro) continua gerando a preferência", async () => {
  const r = await chamar(checkout, { method: "POST", body: base({ email: undefined }) });
  assert.equal(r.status, 200);
  assert.equal(r.corpo.url, "https://mp.test/checkout/pref-1");
  const pref = est.mp.ultimaPreferencia;
  assert.equal(pref.external_reference, r.corpo.ref);
  assert.equal(pref.items.at(-1).id, "taxa");
  assert.equal(doDb(r.corpo.ref).status, "aguardando_pagamento");
  assert.equal(est.mp.chamadasCriar.length, 0); // não usou /v1/payments
});

test("regressão: cartão não exige e-mail e aprovado pelo webhook marca 'Cartão de crédito'", async () => {
  const r = await chamar(checkout, { method: "POST", body: base({ email: undefined }) });
  est.mp.pagamentos.set("55", { id: 55, status: "approved", external_reference: r.corpo.ref, payment_method_id: "master", payment_type_id: "credit_card", metadata: { pedido: "Pedido " + r.corpo.ref } });
  await chamar(webhook, { method: "POST", body: { type: "payment", data: { id: 55 } } });
  assert.equal(doDb(r.corpo.ref).status, "pago");
  assert.equal(doDb(r.corpo.ref).mp_metodo, "Cartão de crédito");
  assert.match(est.telegram[0], /\(Cartão de crédito\)/);
});

test("regressão: pedido por WhatsApp (a_combinar) e fora do horário continua permitido", async () => {
  const r = await comRelogio("2026-10-28T01:00:00Z", () => chamar(checkout, { method: "POST", body: base({ modo: "whatsapp", email: undefined }) }));
  assert.equal(r.status, 200);
  const p = doDb(r.corpo.ref);
  assert.equal(p.status, "a_combinar"); assert.equal(p.forma, "whatsapp"); assert.equal(p.total, 16);
  assert.equal(est.mp.chamadasCriar.length, 0);
});

test("regressão: /api/status, /api/menu e /api/conta", async () => {
  const s = await chamar(status); assert.equal(s.corpo.pagamentoOnline, true); assert.ok(s.corpo.auth);
  const m = await chamar(menu); assert.equal(m.status, 200);
  assert.equal((await chamar(conta)).status, 401);
  const c = await chamar(conta, { headers: { authorization: "Bearer tok-cliente" } });
  assert.equal(c.status, 200); assert.equal(c.corpo.perfil.email, "cliente@teste.com");
  const pr = (await pedirPix({}, { authorization: "Bearer tok-cliente" })).corpo;
  assert.equal((await chamar(conta, { headers: { authorization: "Bearer tok-cliente" } })).corpo.pedidos.length, 0); // aguardando não aparece
  aprovar(pr.pix.id); await consultar(pr.ref);
  const c2 = await chamar(conta, { headers: { authorization: "Bearer tok-cliente" } });
  assert.equal(c2.corpo.pedidos[0].ref, pr.ref);
});

test("regressão: painel /admin exige admin e lista pedidos Pix com mp_metodo", async () => {
  const adm = (a, extra = {}) => chamar(admin, { query: { a }, headers: { authorization: "Bearer tok-admin" }, ...extra });
  assert.equal((await chamar(admin, { query: { a: "pedidos" } })).status, 401);
  assert.equal((await chamar(admin, { query: { a: "pedidos" }, headers: { authorization: "Bearer tok-cliente" } })).status, 403);
  const pr = (await pedirPix()).corpo;
  assert.equal((await adm("pedidos")).corpo.pedidos.length, 0); // aguardando_pagamento não aparece por padrão
  aprovar(pr.pix.id); await consultar(pr.ref);
  const l = (await adm("pedidos")).corpo.pedidos;
  assert.equal(l.length, 1); assert.equal(l[0].mp_metodo, "Pix"); assert.equal(l[0].forma, "online");
  assert.equal((await adm("resumo", { query: { a: "resumo", dias: "7" } })).corpo.kpis.pedidos, 1);
  assert.equal((await adm("itens")).status, 200);
  const st = await adm("pedido_status", { method: "POST", body: { id: l[0].id, status: "em_preparo" } });
  assert.equal(st.status, 200);
  assert.equal((await adm("historico")).status, 200);
  assert.equal((await adm("equipe")).status, 200);
});

test("limites: no máximo 12 funções serverless (arquivos sem '_' em api/)", () => {
  const fs = require("fs"), path = require("path");
  const fns = fs.readdirSync(path.join(__dirname, "..", "api")).filter((f) => f.endsWith(".js") && !f.startsWith("_"));
  assert.deepEqual(fns.sort(), ["admin.js", "checkout.js", "conta.js", "menu.js", "pedido.js", "status.js", "webhook.js"]);
  assert.ok(fns.length <= 12);
});

test("segurança: tokens e chaves não aparecem em nenhuma resposta ao navegador", async () => {
  const rs = [await pedirPix(), await chamar(status), await chamar(menu)];
  const txt = JSON.stringify(rs);
  assert.equal(txt.includes(process.env.MP_ACCESS_TOKEN), false);
  assert.equal(txt.includes(process.env.SUPABASE_SERVICE_ROLE_KEY), false);
});

test("sem dependências npm", () => {
  const pkg = require("../package.json");
  assert.equal(pkg.dependencies, undefined); assert.equal(pkg.devDependencies, undefined);
});
