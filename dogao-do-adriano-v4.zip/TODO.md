# TODO — Dogão do Adriano

Legenda: [x] concluído e verificado · [ ] pendente · P1 alta, P2 média, P3 baixa.

## Em andamento
- [ ] P2 · Etapa B: alerta de pedido novo no `/admin` (som/destaque ao chegar pedido). Próxima a executar.

## Pendentes
- [ ] P1 · (dono) Testar Pix real de R$ 4–5 de outro banco, conferir Telegram e `/admin`, estornar.
- [ ] P1 · (dono) Diagnosticar login ausente: abrir `/api/status`; se `"auth":null`, conferir `SUPABASE_URL` e `SUPABASE_ANON_KEY` na Vercel e fazer Redeploy.
- [ ] P2 · Etapa C: página de política de privacidade/termos (LGPD) e link no rodapé.
- [ ] P2 · Etapa D: comanda para imprimir/ver na cozinha no `/admin`.
- [ ] P3 · Etapa E: horários editáveis pelo painel.
- [ ] P3 · Etapa F: taxa de entrega por bairro.
- [ ] P3 · Etapa G: avisar o cliente quando o pedido estiver pronto.
- [ ] P2 · Responder ao dono: custos (hospedagem, domínio, taxas Mercado Pago) e quanto cobrar. Pesquisa de preços foi interrompida pelo limite de uso; refazer.

## Concluídas
- [x] Etapa A: aviso no Telegram para pedidos por WhatsApp — API 37/37 e navegador 19/19
- [x] Pix no site (backend + front) — testado (API 35/35, navegador 19/19 simulados)
- [x] `/api/pedido` sem dados pessoais
- [x] Aviso de pagamento aprovado uma única vez
- [x] Correção de rolagem horizontal do cabeçalho em 390 px
- [x] README atualizado (chave Pix, teste real, pagamentos)
- [x] Bot do Telegram configurado pelo dono (token e chat ID na Vercel)
- [x] Arquivos de acompanhamento TODO.md e PROGRESSO.md criados
