// Teste no navegador (Playwright) com Supabase e Mercado Pago simulados. Rodar: node tests/browser.test.js
// Opcional: FOTOS=1 salva capturas de tela em tests/fotos/
const http = require("http"), fs = require("fs"), path = require("path");
const assert = require("node:assert/strict");
const h = require("./harness");
const { est, api, aprovar, definirStatus } = h;
const { chromium } = require("playwright");

const PUBLIC = path.join(__dirname, "..", "public");
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".json": "application/json" };
const rotas = { checkout: api("checkout.js"), pedido: api("pedido.js"), webhook: api("webhook.js"), conta: api("conta.js"), admin: api("admin.js"), status: api("status.js"), menu: api("menu.js") };

const servidor = http.createServer(async (req, res) => {
  const u = new URL(req.url, "http://localhost");
  if (u.pathname.startsWith("/api/")) {
    const fn = rotas[u.pathname.slice(5)];
    if (!fn) { res.writeHead(404); return res.end(); }
    const chunks = []; for await (const c of req) chunks.push(c);
    const txt = Buffer.concat(chunks).toString();
    let body; try { body = txt ? JSON.parse(txt) : undefined; } catch { body = txt; }
    const r = { method: req.method, headers: req.headers, query: Object.fromEntries(u.searchParams), body };
    const hdrs = {}; let code = 200;
    const o = { setHeader: (k, v) => { hdrs[k] = v; }, status(c) { code = c; return this; },
      json(x) { res.writeHead(code, { "Content-Type": "application/json", ...hdrs }); res.end(JSON.stringify(x)); },
      send(x) { res.writeHead(code, hdrs); res.end(String(x)); } };
    try { await fn(r, o); } catch (e) { console.error(e); res.writeHead(500); res.end(); }
    return;
  }
  let f = path.join(PUBLIC, u.pathname); if (f.endsWith("/")) f += "index.html";
  fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end(); } res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream" }); res.end(d); });
});

let ok = 0;
const passo = async (nome, fn) => { try { await fn(); ok++; console.log("  ✓", nome); } catch (e) { console.log("  ✗", nome, "\n    ", e.message.split("\n").slice(0, 6).join("\n     ")); process.exitCode = 1; } };
const FOTOS = process.env.FOTOS ? path.join(__dirname, "fotos") : null; if (FOTOS) fs.mkdirSync(FOTOS, { recursive: true });

async function novaPagina(browser, base, opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, permissions: ["clipboard-read", "clipboard-write"], ...opts });
  const page = await ctx.newPage();
  const reqs = []; page.on("request", (r) => reqs.push(r.method() + " " + r.url()));
  const erros = []; page.on("pageerror", (e) => erros.push(e.message));
  // tudo que não é local é bloqueado/simulado (fontes do Google, Supabase Auth, Mercado Pago, WhatsApp)
  await ctx.route((u) => !u.href.startsWith(base), async (route) => {
    const u = route.request().url();
    if (u.includes("/auth/v1/token?grant_type=password")) return route.fulfill({ json: { access_token: "tok-cliente", refresh_token: "r", expires_in: 3600, user: { email: "cliente@teste.com" } } });
    if (u.includes("mp.test") || u.includes("wa.me")) return route.fulfill({ contentType: "text/html", body: "<title>externo</title>externo" });
    return route.abort();
  });
  return { ctx, page, reqs, erros };
}
const montarPedido = async (page, { email = "maria@exemplo.com" } = {}) => {
  await page.goto("/"); await page.locator("[data-add]").first().waitFor();
  await page.locator("[data-add]").first().click(); // Dogão Tradicional (R$ 18)
  await page.click("#openCart");
  await page.fill("#nome", "Maria da Silva"); await page.fill("#tel", "11999991234"); await page.fill("#end", "Rua das Flores, 123");
  if (email !== null) await page.fill("#email", email);
};
const esperar = async (cond, ms = 8000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await cond()) return; await new Promise((r) => setTimeout(r, 100)); } throw new Error("tempo esgotado"); };
// compara com a largura configurada do aparelho (innerWidth cresce quando algo transborda, então não serve)
const semRolagemHorizontal = (page) => page.evaluate((w) => document.documentElement.scrollWidth <= w && document.body.scrollWidth <= w, page.viewportSize().width);

(async () => {
  await new Promise((r) => servidor.listen(0, r));
  const base = `http://localhost:${servidor.address().port}`;
  const browser = await chromium.launch();
  const mk = (opts) => novaPagina(browser, base, { baseURL: base, ...opts });
  console.log("Teste de navegador —", base);

  // ===== Fluxo principal em 390 px, tema claro =====
  const A = await mk(); const page = A.page;
  let refAtual;
  await passo("carrinho: campo e-mail, botões Pix/cartão/WhatsApp e rodapé novos", async () => {
    await montarPedido(page, { email: null });
    assert.equal(await page.locator("#email").getAttribute("type"), "email");
    assert.equal(await page.locator("#email").getAttribute("autocomplete"), "email");
    assert.match(await page.locator('label[for="email"]').innerText(), /E-mail \(para o Pix\)/);
    assert.equal(await page.innerText("#pix"), "Pagar com Pix");
    assert.equal(await page.innerText("#pagar"), "Pagar com cartão (Mercado Pago)");
    assert.match(await page.innerText("#zap"), /WhatsApp/);
    assert.match(await page.innerText(".fine"), /Pix e cartão processados pelo Mercado Pago/);
    assert.equal(await page.locator("#pix").isEnabled(), true);
    assert.equal(await page.locator("#pagar").isEnabled(), true);
    assert.ok(await semRolagemHorizontal(page), "rolagem horizontal com a gaveta aberta");
    if (FOTOS) await page.screenshot({ path: FOTOS + "/1-carrinho-390.png" });
  });
  await passo("Pix exige e-mail válido no navegador (sem chamar a API)", async () => {
    const antes = A.reqs.filter((r) => r.includes("/api/checkout")).length;
    await page.click("#pix");
    assert.equal(await page.innerText("#erro"), "Informe um e-mail válido para o Pix.");
    await page.fill("#email", "errado@"); await page.click("#pix");
    assert.equal(await page.innerText("#erro"), "Informe um e-mail válido para o Pix.");
    assert.equal(A.reqs.filter((r) => r.includes("/api/checkout")).length, antes);
    await page.fill("#email", "maria@exemplo.com");
    assert.equal(await page.locator("#erro").isHidden(), true);
  });
  await passo("Pagar com Pix: janela com QR, código, contagem regressiva e status", async () => {
    await page.click("#pix");
    await page.locator("#dlgPix[open]").waitFor();
    refAtual = est.tabelas.pedidos.at(-1).ref;
    const src = await page.getAttribute("#pixQr", "src");
    assert.match(src, /^data:image\/png;base64,/);
    assert.equal(await page.getAttribute("#pixQr", "alt"), "QR code do Pix");
    assert.equal(await page.locator("#pixQr").evaluate((i) => i.complete && i.naturalWidth > 0), true);
    const copia = await page.inputValue("#pixCopia"); assert.match(copia, /^000201/);
    assert.match(await page.innerText("#pixTempo"), /^(29|30):\d\d$/);
    assert.equal(await page.innerText("#pixStatus"), "Aguardando pagamento…");
    assert.equal(await page.getAttribute("#pixStatus", "aria-live"), "polite");
    assert.match(await page.innerText("#pixValor"), /24,00/); // R$ 18 + taxa R$ 6
    assert.match(await page.innerText("#pixDica"), /No celular: toque em Copiar código, abra o app do seu banco e use Pix > Pix Copia e Cola\./);
    assert.equal(await page.evaluate(() => document.activeElement.id), "dlgPix", "foco no dialog");
    assert.ok(await semRolagemHorizontal(page), "rolagem horizontal com o Pix aberto");
    const caixa = await page.locator("#dlgPix").boundingBox(); assert.ok(caixa.width <= 390 && caixa.x >= 0, JSON.stringify(caixa));
    for (const sel of ["#pixCopiar", "#pixFechar"]) assert.ok((await page.locator(sel).boundingBox()).height >= 44, sel + " < 44px");
    if (FOTOS) await page.screenshot({ path: FOTOS + "/2-pix-390-claro.png" });
    assert.equal(est.tabelas.pedidos.at(-1).status, "aguardando_pagamento");
  });
  await passo("contagem regressiva anda", async () => {
    const t1 = await page.innerText("#pixTempo"); await page.waitForTimeout(2300);
    assert.notEqual(await page.innerText("#pixTempo"), t1);
  });
  await passo("Copiar código Pix coloca o código na área de transferência", async () => {
    await page.click("#pixCopiar");
    assert.equal(await page.evaluate(() => navigator.clipboard.readText()), await page.inputValue("#pixCopia"));
    assert.match(await page.innerText("#pixCopiar"), /copiado/);
  });
  await passo("Copiar: se a área de transferência falhar, o código fica selecionado", async () => {
    await page.evaluate(() => { Object.defineProperty(navigator, "clipboard", { value: { writeText: () => Promise.reject(new Error("negado")) }, configurable: true }); });
    await page.click("#pixCopiar");
    const sel = await page.evaluate(() => { const e = document.getElementById("pixCopia"); return e.value.slice(e.selectionStart, e.selectionEnd); });
    assert.equal(sel, await page.inputValue("#pixCopia"));
  });
  await passo("polling: consulta /api/pedido a cada ~4 s sem trazer dados pessoais", async () => {
    const n0 = A.reqs.filter((r) => r.includes("/api/pedido?ref=")).length;
    await page.waitForTimeout(8500);
    const n1 = A.reqs.filter((r) => r.includes("/api/pedido?ref=")).length;
    assert.ok(n1 - n0 >= 2 && n1 - n0 <= 3, "consultas em 8,5 s: " + (n1 - n0));
  });
  await passo("pagamento aprovado: fecha a janela do Pix, mostra 'Pagamento aprovado' e esvazia o carrinho", async () => {
    aprovar(est.tabelas.pedidos.at(-1).mp_payment_id);
    await page.locator("#resultado[open]").waitFor({ timeout: 9000 });
    assert.equal(await page.locator("#dlgPix").evaluate((d) => d.open), false);
    assert.equal(await page.innerText("#resTitulo"), "Pagamento aprovado! 🎉");
    assert.match(await page.innerText("#resTexto"), new RegExp(refAtual));
    assert.match(await page.innerText("#resPedido"), new RegExp(`Pedido ${refAtual}`));
    assert.equal(await page.innerText("#resZap"), "Enviar detalhes ao Adriano no WhatsApp");
    assert.match(await page.getAttribute("#resZap", "href"), /^https:\/\/wa\.me\/5511990173256\?text=/);
    assert.equal(await page.innerText("#count"), "0");
    assert.equal(await page.evaluate(() => localStorage.getItem("dogao_cart")), "[]");
    assert.equal(await page.evaluate(() => localStorage.getItem("dogao_pedido")), null);
    assert.equal(est.telegram.length, 1);
    if (FOTOS) await page.screenshot({ path: FOTOS + "/3-aprovado-390.png" });
  });
  await passo("sem erros de JavaScript no fluxo", async () => assert.deepEqual(A.erros, []));
  await A.ctx.close();

  // ===== Esc fecha e interrompe o polling; expiração; recusado; novo código =====
  const B = await mk(); const pb = B.page; const nPedidos = est.tabelas.pedidos.length;
  await passo("Esc fecha a janela do Pix e para o polling", async () => {
    await montarPedido(pb); await pb.click("#pix"); await pb.locator("#dlgPix[open]").waitFor();
    await pb.keyboard.press("Escape");
    assert.equal(await pb.locator("#dlgPix").evaluate((d) => d.open), false);
    await pb.waitForTimeout(500);
    const n0 = B.reqs.filter((r) => r.includes("/api/pedido?ref=")).length;
    await pb.waitForTimeout(5000);
    assert.equal(B.reqs.filter((r) => r.includes("/api/pedido?ref=")).length, n0, "continuou consultando após fechar");
    assert.equal(await pb.locator("#drawer").evaluate((d) => d.classList.contains("on")), true, "Esc no Pix não deve fechar a gaveta");
  });
  await passo("pagamento recusado/cancelado: 'Nada foi cobrado' + botão para tentar de novo", async () => {
    await pb.click("#pix"); await pb.locator("#dlgPix[open]").waitFor();
    definirStatus(est.tabelas.pedidos.at(-1).mp_payment_id, "cancelled");
    await pb.waitForFunction(() => /Nada foi cobrado/.test(document.getElementById("pixStatus").textContent), null, { timeout: 9000 });
    assert.equal(await pb.innerText("#pixStatus"), "Pagamento não concluído. Nada foi cobrado. Tente de novo.");
    assert.equal(await pb.locator("#pixNovo").isVisible(), true);
    await pb.click("#pixNovo");
    await pb.waitForFunction(() => document.getElementById("dlgPix").open && /Aguardando/.test(document.getElementById("pixStatus").textContent));
    assert.equal(est.tabelas.pedidos.length, nPedidos + 3); // 1º Pix, 2º Pix (cancelado) e o novo código
    assert.equal(await pb.locator("#pixNovo").isHidden(), true);
  });
  await pb.keyboard.press("Escape"); await B.ctx.close();

  const C = await mk();
  await passo("código expirado: 'O código expirou. Gere um novo.' e geração de outro", async () => {
    await C.page.clock.install();
    await montarPedido(C.page); await C.page.click("#pix"); await C.page.locator("#dlgPix[open]").waitFor();
    const n = est.tabelas.pedidos.length;
    await C.page.clock.fastForward("31:00");
    await esperar(async () => /expirou/.test(await C.page.innerText("#pixStatus"))); // (com o relógio falso, waitForFunction não anda)
    assert.equal(await C.page.innerText("#pixStatus"), "O código expirou. Gere um novo.");
    assert.equal(await C.page.innerText("#pixTempo"), "00:00");
    assert.equal(await C.page.locator("#pixCorpo").isHidden(), true);
    const codigoAntigo = await C.page.inputValue("#pixCopia");
    await C.page.click("#pixNovo");
    await esperar(async () => est.tabelas.pedidos.length === n + 1);
    // (o relógio do navegador está 31 min adiantado em relação ao servidor de teste, então não olhamos o status depois daqui)
    const novo = est.tabelas.pedidos.at(-1);
    assert.equal(novo.status, "aguardando_pagamento"); assert.equal(novo.mp_metodo, "Pix");
    await esperar(async () => (await C.page.inputValue("#pixCopia")) !== codigoAntigo);
    assert.match(await C.page.inputValue("#pixCopia"), /^000201/);
  });
  await C.ctx.close();

  // ===== modo escuro =====
  const D = await mk({ colorScheme: "dark" });
  await passo("modo escuro: janela do Pix legível, QR em fundo branco, sem rolagem horizontal", async () => {
    await montarPedido(D.page); await D.page.click("#pix"); await D.page.locator("#dlgPix[open]").waitFor();
    const cores = await D.page.evaluate(() => { const c = (s, p) => getComputedStyle(document.querySelector(s))[p]; return { dlg: c("#dlgPix", "backgroundColor"), txt: c("#dlgPix", "color"), qr: c("#pixQr", "backgroundColor"), valor: c("#pixValor", "color") }; });
    const lum = (rgb) => { const [r, g, b] = rgb.match(/\d+/g).map(Number); return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255; };
    assert.ok(lum(cores.dlg) < 0.25, "fundo escuro: " + cores.dlg);
    assert.ok(lum(cores.txt) > 0.7, "texto claro: " + cores.txt);
    assert.ok(lum(cores.valor) > 0.5, "valor legível: " + cores.valor);
    assert.ok(lum(cores.qr) > 0.95, "QR sobre fundo branco: " + cores.qr);
    assert.ok(await semRolagemHorizontal(D.page));
    if (FOTOS) await D.page.screenshot({ path: FOTOS + "/4-pix-390-escuro.png" });
  });
  await D.ctx.close();

  // ===== desktop =====
  const E = await mk({ viewport: { width: 1280, height: 800 }, isMobile: false, hasTouch: false });
  await passo("desktop: instrução para escanear o QR code", async () => {
    await montarPedido(E.page); await E.page.click("#pix"); await E.page.locator("#dlgPix[open]").waitFor();
    assert.match(await E.page.innerText("#pixDica"), /escaneie o QR code/);
    if (FOTOS) await E.page.screenshot({ path: FOTOS + "/5-pix-desktop.png" });
  });
  await E.ctx.close();

  // ===== Pix indisponível =====
  const F = await mk();
  await passo("Pix indisponível: mensagem amigável em #erro e nenhuma janela", async () => {
    est.mp.falhar = { status: 400, corpo: { message: "Collector user without key enabled for QR render" } };
    const orig = console.error; console.error = () => {};
    try { await montarPedido(F.page); await F.page.click("#pix"); await F.page.waitForFunction(() => !document.getElementById("erro").hidden); } finally { console.error = orig; est.mp.falhar = null; }
    assert.equal(await F.page.innerText("#erro"), "Pix indisponível no momento. Pague com cartão ou combine pelo WhatsApp.");
    assert.equal(await F.page.locator("#dlgPix").evaluate((d) => d.open), false);
    assert.equal(await F.page.locator("#pix").isEnabled(), true);
    assert.equal(await F.page.innerText("#pix"), "Pagar com Pix");
  });
  await F.ctx.close();

  // ===== Regressão: cartão, WhatsApp, login e Minha conta, painel =====
  const G = await mk();
  await passo("regressão: cartão segue para o Checkout Pro (sem e-mail)", async () => {
    await montarPedido(G.page, { email: null });
    const resp = G.page.waitForRequest((r) => r.url().includes("mp.test/checkout/pref-1"));
    await G.page.click("#pagar"); await resp;
    const corpo = est.tabelas.pedidos.at(-1);
    assert.equal(corpo.status, "aguardando_pagamento"); assert.equal(corpo.forma, "online");
    assert.equal(est.mp.ultimaPreferencia.external_reference, corpo.ref);
  });
  const H = await mk();
  await passo("regressão: WhatsApp registra o pedido, abre wa.me e limpa o carrinho", async () => {
    await montarPedido(H.page, { email: null });
    const [popup] = await Promise.all([H.ctx.waitForEvent("page"), H.page.click("#zap")]);
    await popup.waitForURL(/wa\.me/, { timeout: 8000 }).catch(() => {});
    assert.match(popup.url(), /wa\.me\/\d+\?text=/);
    const p = est.tabelas.pedidos.at(-1); assert.equal(p.forma, "whatsapp"); assert.equal(p.status, "a_combinar");
    await H.page.waitForFunction(() => document.getElementById("count").textContent === "0");
  });
  await H.ctx.close();
  const I = await mk();
  await passo("regressão: login, e-mail preenchido no carrinho e 'Minha conta'", async () => {
    await I.page.goto("/"); await I.page.locator("[data-add]").first().waitFor();
    await I.page.click("#openConta"); await I.page.fill("#lgEmail", "cliente@teste.com"); await I.page.fill("#lgSenha", "senha12345");
    await I.page.click("#lgOk"); await I.page.waitForFunction(() => /Cliente/.test(document.getElementById("openConta").textContent));
    await I.page.click("[data-add]"); await I.page.click("#openCart");
    assert.equal(await I.page.inputValue("#email"), "cliente@teste.com");
    assert.equal(await I.page.inputValue("#nome"), "Cliente Logado");
    await I.page.keyboard.press("Escape"); await I.page.click("#openConta");
    await I.page.locator("#dlgConta[open]").waitFor();
    assert.equal(await I.page.innerText("#contaEmail"), "cliente@teste.com");
    // Pix logado: o pedido leva o user_id e aparece em "Minha conta" depois de pago
    await I.page.keyboard.press("Escape"); await I.page.click("#openCart"); await I.page.fill("#tel", "11999991234"); await I.page.fill("#end", "Rua das Flores, 123");
    await I.page.click("#pix"); await I.page.locator("#dlgPix[open]").waitFor();
    assert.equal(est.tabelas.pedidos.at(-1).user_id, "u-cliente");
  });
  await I.ctx.close();
  const J = await mk();
  await passo("regressão: painel /admin lista o pedido Pix pago ('pago online (Pix)') e escapa HTML", async () => {
    const pago = est.tabelas.pedidos.find((p) => p.status === "pago");
    pago.nome = '<img src=x onerror="window.__xss=1">'; pago.obs = "<b>negrito</b>";
    await J.ctx.addInitScript(() => localStorage.setItem("dogao_auth", JSON.stringify({ access_token: "tok-admin", refresh_token: "r", exp: Date.now() + 3600e3, email: "admin@teste.com" })));
    await J.page.goto("/admin/");
    await J.page.click('[data-t="pedidos"]');
    await J.page.waitForFunction(() => /pago online \(Pix\)/.test(document.body.innerText), null, { timeout: 8000 });
    assert.equal(await J.page.evaluate(() => window.__xss), undefined);
    assert.deepEqual(J.erros, []);
  });
  await J.ctx.close();

  await browser.close(); servidor.close();
  console.log(`\n${ok} verificações passaram${process.exitCode ? ", HÁ FALHAS" : ""}.`);
})().catch((e) => { console.error(e); process.exit(1); });
