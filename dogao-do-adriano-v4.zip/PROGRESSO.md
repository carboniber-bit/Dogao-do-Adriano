# PROGRESSO — Dogão do Adriano

> Estado real do projeto. Atualize junto com TODO.md ao fim de cada etapa. Nunca registre senhas, tokens ou chaves aqui.

## Objetivo geral
Site de pedidos do Dogão do Adriano (Osasco/SP) na Vercel + Supabase, com pagamento sem exigir conta no Mercado Pago:
Pix dentro do site (QR + copia e cola), cartão via Checkout Pro e pedido por WhatsApp (pagar na entrega). Avisos de pedido por Telegram.

## Concluído
- Pix no site (`POST /v1/payments` do Mercado Pago), com polling do status e tela "Pagamento aprovado".
- Aviso único de pagamento aprovado (webhook e polling não duplicam).
- `GET /api/pedido?ref=` devolve só `{status}` (sem dados pessoais).
- Campo e-mail no carrinho (só para o Pix; não é gravado nem logado).
- Correção do cabeçalho em 390 px (rolagem horizontal).
- Testes automáticos (API e navegador) com Supabase e Mercado Pago simulados.
- README com pré-requisito da chave Pix, teste real e seção de pagamentos.
- Etapa A: `api/checkout.js` avisa no Telegram os pedidos por WhatsApp (texto "🕒 NOVO PEDIDO (pagar na entrega/retirada)"); falha do Telegram não derruba o pedido.
- Bot do Telegram criado e chat ID obtido pelo dono; variáveis colocadas na Vercel e redeploy feito.

## Arquivos alterados/criados na etapa Pix
- Novos: `api/_pagamento.js`, `api/pedido.js`, `tests/harness.js`, `tests/api.test.js`, `tests/browser.test.js`, `TODO.md`, `PROGRESSO.md`
- Alterados: `api/checkout.js` (modo pix; aviso do WhatsApp), `api/webhook.js` (refatorado), `public/index.html` (e-mail, botões, janela Pix, cabeçalho), `README.md`, `package.json` (scripts de teste)
- `public/admin/index.html`: sem mudança (já mostra `mp_metodo`).

## O que está funcionando (verificado)
- `node tests/api.test.js`: 37/37 passam.
- `node tests/browser.test.js`: 19/19 passam.
- Funções serverless: 7 (limite do plano gratuito: 12).

## Erros conhecidos / pontos em aberto
- Pix real ainda NÃO foi provado contra o Mercado Pago de produção (só simulado). Depende do dono testar com R$ 4–5.
- Dono relatou que o botão "Entrar" (login) não apareceu no site publicado. Causa provável: `SUPABASE_URL`/`SUPABASE_ANON_KEY` ausentes na Vercel (o botão só aparece se `/api/status` devolve `auth`). Não confirmado.
- Aviso de Telegram: agora cobre pagamento aprovado e pedidos por WhatsApp. Falta o dono publicar (commit + redeploy) para valer no site.
- Horários de atendimento e taxa de entrega por bairro não são editáveis pelo painel.

## Testes executados e resultados
| Teste | Resultado |
|---|---|
| `node tests/api.test.js` | 37 passam, 0 falham (após etapa A) |
| `node tests/browser.test.js` | 19 passam (após etapa A) |

## Próxima ação exata
Etapa B do TODO.md: alerta de pedido novo no `/admin` (arquivo `public/admin/index.html`; a aba Pedidos já consulta `/api/admin?a=pedidos`). Antes, rodar `node tests/api.test.js`.

## Configurações externas que dependem do dono
- Chave Pix cadastrada na mesma conta Mercado Pago do `MP_ACCESS_TOKEN` (produção).
- Variáveis na Vercel: `MP_ACCESS_TOKEN`, `SITE_URL`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` (Production) + Redeploy após qualquer mudança.
- Commit no GitHub e redeploy da versão com Pix.
- Teste real: Pix pequeno de outro banco e estorno depois.
- Decisões comerciais: hospedagem paga (Vercel Pro/Supabase Pro), domínio próprio, preço do serviço.

## Como retomar numa nova sessão
1. Ler este arquivo e TODO.md. 2. `node tests/api.test.js` para confirmar o estado. 3. Seguir a "Próxima ação exata". 4. Não refazer itens concluídos.
